
const typed = new Typed('.multiple-text', {
  strings: ['Freelancer', 'Designer', 'Editor'],
  typeSpeed: 100,
  backSpeed: 100,
  backDelay: 1000,
  loop: true
});

ScrollReveal().reveal('.home-content, .heading', { origin: 'top', distance: '80px', duration: 2000, reset: true });
ScrollReveal().reveal('.home-img, .services-content, .skills-content', { origin: 'bottom', distance: '80px', duration: 2000, reset: true });
ScrollReveal().reveal('.contact-info, .about-content', { origin: 'left', distance: '80px', duration: 2000, reset: true });
